[Back to the Ling/Light_Logger api](https://github.com/lingtalfi/Light_Logger/blob/master/doc/api/Ling/Light_Logger.md)<br>
[Back to the Ling\Light_Logger\LightLoggerService class](https://github.com/lingtalfi/Light_Logger/blob/master/doc/api/Ling/Light_Logger/LightLoggerService.md)


LightLoggerService::setUseExpandedArray
================



LightLoggerService::setUseExpandedArray — Sets the useExpandedArray.




Description
================


public [LightLoggerService::setUseExpandedArray](https://github.com/lingtalfi/Light_Logger/blob/master/doc/api/Ling/Light_Logger/LightLoggerService/setUseExpandedArray.md)(bool $useExpandedArray) : void




Sets the useExpandedArray.




Parameters
================


- useExpandedArray

    


Return values
================

Returns void.








Source Code
===========
See the source code for method [LightLoggerService::setUseExpandedArray](https://github.com/lingtalfi/Light_Logger/blob/master/LightLoggerService.php#L164-L167)


See Also
================

The [LightLoggerService](https://github.com/lingtalfi/Light_Logger/blob/master/doc/api/Ling/Light_Logger/LightLoggerService.md) class.

Previous method: [setFormat](https://github.com/lingtalfi/Light_Logger/blob/master/doc/api/Ling/Light_Logger/LightLoggerService/setFormat.md)<br>Next method: [log](https://github.com/lingtalfi/Light_Logger/blob/master/doc/api/Ling/Light_Logger/LightLoggerService/log.md)<br>

