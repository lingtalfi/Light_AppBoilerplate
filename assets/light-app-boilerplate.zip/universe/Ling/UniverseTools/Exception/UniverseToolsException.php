<?php


namespace Ling\UniverseTools\Exception;


/**
 * The base exception class for the UniverseTools planet.
 */
class UniverseToolsException extends \Exception
{

}