[Back to the Ling/UniverseTools api](https://github.com/lingtalfi/UniverseTools/blob/master/doc/api/Ling/UniverseTools.md)<br>
[Back to the Ling\UniverseTools\BangTool class](https://github.com/lingtalfi/UniverseTools/blob/master/doc/api/Ling/UniverseTools/BangTool.md)


BangTool::bangApp
================



BangTool::bangApp — Bangs the given application directory.




Description
================


public static [BangTool::bangApp](https://github.com/lingtalfi/UniverseTools/blob/master/doc/api/Ling/UniverseTools/BangTool/bangApp.md)(string $appDir) : void




Bangs the given application directory.

See https://github.com/lingtalfi/UniverseTools/blob/master/doc/pages/nomenclature.md#bang for more details.




Parameters
================


- appDir

    


Return values
================

Returns void.








Source Code
===========
See the source code for method [BangTool::bangApp](https://github.com/lingtalfi/UniverseTools/blob/master/BangTool.php#L51-L58)


See Also
================

The [BangTool](https://github.com/lingtalfi/UniverseTools/blob/master/doc/api/Ling/UniverseTools/BangTool.md) class.

Previous method: [bang](https://github.com/lingtalfi/UniverseTools/blob/master/doc/api/Ling/UniverseTools/BangTool/bang.md)<br>

