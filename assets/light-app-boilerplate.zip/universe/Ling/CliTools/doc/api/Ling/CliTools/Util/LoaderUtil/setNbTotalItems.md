[Back to the Ling/CliTools api](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools.md)<br>
[Back to the Ling\CliTools\Util\LoaderUtil class](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/LoaderUtil.md)


LoaderUtil::setNbTotalItems
================



LoaderUtil::setNbTotalItems — Sets the nbTotalItems.




Description
================


public [LoaderUtil::setNbTotalItems](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/LoaderUtil/setNbTotalItems.md)(int $nbTotalItems) : void




Sets the nbTotalItems.




Parameters
================


- nbTotalItems

    


Return values
================

Returns void.








Source Code
===========
See the source code for method [LoaderUtil::setNbTotalItems](https://github.com/lingtalfi/CliTools/blob/master/Util/LoaderUtil.php#L71-L74)


See Also
================

The [LoaderUtil](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/LoaderUtil.md) class.

Previous method: [setOutput](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/LoaderUtil/setOutput.md)<br>Next method: [setDisplayMode](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/LoaderUtil/setDisplayMode.md)<br>

