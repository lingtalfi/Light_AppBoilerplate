[Back to the Ling/CliTools api](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools.md)<br>
[Back to the Ling\CliTools\Formatter\BashtmlFormatter class](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Formatter/BashtmlFormatter.md)


BashtmlFormatter::format
================



BashtmlFormatter::format — Parses the given $expression and returns its formatted/interpreted version.




Description
================


public [BashtmlFormatter::format](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Formatter/BashtmlFormatter/format.md)(string $expression) : string




Parses the given $expression and returns its formatted/interpreted version.




Parameters
================


- expression

    


Return values
================

Returns string.








Source Code
===========
See the source code for method [BashtmlFormatter::format](https://github.com/lingtalfi/CliTools/blob/master/Formatter/BashtmlFormatter.php#L283-L317)


See Also
================

The [BashtmlFormatter](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Formatter/BashtmlFormatter.md) class.

Previous method: [setFormatMode](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Formatter/BashtmlFormatter/setFormatMode.md)<br>Next method: [addParent](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Formatter/BashtmlFormatter/addParent.md)<br>

