[Back to the Ling/CliTools api](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools.md)<br>
[Back to the Ling\CliTools\Formatter\DumbFormatter class](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Formatter/DumbFormatter.md)


DumbFormatter::format
================



DumbFormatter::format — Parses the given $expression and returns its formatted/interpreted version.




Description
================


public [DumbFormatter::format](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Formatter/DumbFormatter/format.md)(string $expression) : string




Parses the given $expression and returns its formatted/interpreted version.




Parameters
================


- expression

    


Return values
================

Returns string.








Source Code
===========
See the source code for method [DumbFormatter::format](https://github.com/lingtalfi/CliTools/blob/master/Formatter/DumbFormatter.php#L21-L24)


See Also
================

The [DumbFormatter](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Formatter/DumbFormatter.md) class.



