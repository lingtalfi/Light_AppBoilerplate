[Back to the Ling/CliTools api](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools.md)<br>
[Back to the Ling\CliTools\Util\LoaderUtil class](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/LoaderUtil.md)


LoaderUtil::refreshDisplay
================



LoaderUtil::refreshDisplay — Refreshes the display of the widget.




Description
================


protected [LoaderUtil::refreshDisplay](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/LoaderUtil/refreshDisplay.md)() : void




Refreshes the display of the widget.




Parameters
================

This method has no parameters.


Return values
================

Returns void.








Source Code
===========
See the source code for method [LoaderUtil::refreshDisplay](https://github.com/lingtalfi/CliTools/blob/master/Util/LoaderUtil.php#L115-L149)


See Also
================

The [LoaderUtil](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/LoaderUtil.md) class.

Previous method: [start](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/LoaderUtil/start.md)<br>

