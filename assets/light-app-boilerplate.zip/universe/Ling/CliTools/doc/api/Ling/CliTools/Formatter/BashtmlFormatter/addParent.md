[Back to the Ling/CliTools api](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools.md)<br>
[Back to the Ling\CliTools\Formatter\BashtmlFormatter class](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Formatter/BashtmlFormatter.md)


BashtmlFormatter::addParent
================



BashtmlFormatter::addParent — Adds a parent to the stack.




Description
================


private [BashtmlFormatter::addParent](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Formatter/BashtmlFormatter/addParent.md)(string $name) : void




Adds a parent to the stack.




Parameters
================


- name

    


Return values
================

Returns void.








Source Code
===========
See the source code for method [BashtmlFormatter::addParent](https://github.com/lingtalfi/CliTools/blob/master/Formatter/BashtmlFormatter.php#L329-L332)


See Also
================

The [BashtmlFormatter](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Formatter/BashtmlFormatter.md) class.

Previous method: [format](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Formatter/BashtmlFormatter/format.md)<br>Next method: [removeParent](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Formatter/BashtmlFormatter/removeParent.md)<br>

