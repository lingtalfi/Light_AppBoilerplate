[Back to the Ling/CliTools api](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools.md)<br>
[Back to the Ling\CliTools\Util\TableUtil class](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/TableUtil.md)


TableUtil::setHeaders
================



TableUtil::setHeaders — Sets the headers.




Description
================


public [TableUtil::setHeaders](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/TableUtil/setHeaders.md)(array $headers) : void




Sets the headers.




Parameters
================


- headers

    


Return values
================

Returns void.








Source Code
===========
See the source code for method [TableUtil::setHeaders](https://github.com/lingtalfi/CliTools/blob/master/Util/TableUtil.php#L106-L109)


See Also
================

The [TableUtil](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/TableUtil.md) class.

Previous method: [__construct](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/TableUtil/__construct.md)<br>Next method: [setOptions](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/TableUtil/setOptions.md)<br>

