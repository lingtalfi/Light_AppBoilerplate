[Back to the Ling/CliTools api](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools.md)<br>
[Back to the Ling\CliTools\Input\WritableCommandLineInput class](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Input/WritableCommandLineInput.md)


WritableCommandLineInput::rewriteParameterIndexes
================



WritableCommandLineInput::rewriteParameterIndexes — 




Description
================


private [WritableCommandLineInput::rewriteParameterIndexes](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Input/WritableCommandLineInput/rewriteParameterIndexes.md)() : void




Rewrite the parameter indexes




Parameters
================

This method has no parameters.


Return values
================

Returns void.








Source Code
===========
See the source code for method [WritableCommandLineInput::rewriteParameterIndexes](https://github.com/lingtalfi/CliTools/blob/master/Input/WritableCommandLineInput.php#L55-L64)


See Also
================

The [WritableCommandLineInput](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Input/WritableCommandLineInput.md) class.

Previous method: [setParameters](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Input/WritableCommandLineInput/setParameters.md)<br>

