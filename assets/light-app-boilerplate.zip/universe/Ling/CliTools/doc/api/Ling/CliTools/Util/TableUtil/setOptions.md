[Back to the Ling/CliTools api](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools.md)<br>
[Back to the Ling\CliTools\Util\TableUtil class](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/TableUtil.md)


TableUtil::setOptions
================



TableUtil::setOptions — Sets the options.




Description
================


public [TableUtil::setOptions](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/TableUtil/setOptions.md)(array $options) : void




Sets the options.




Parameters
================


- options

    


Return values
================

Returns void.








Source Code
===========
See the source code for method [TableUtil::setOptions](https://github.com/lingtalfi/CliTools/blob/master/Util/TableUtil.php#L116-L119)


See Also
================

The [TableUtil](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/TableUtil.md) class.

Previous method: [setHeaders](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/TableUtil/setHeaders.md)<br>Next method: [setRows](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/TableUtil/setRows.md)<br>

