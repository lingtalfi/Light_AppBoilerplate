[Back to the Ling/CliTools api](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools.md)<br>
[Back to the Ling\CliTools\Formatter\FormatterInterface class](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Formatter/FormatterInterface.md)


FormatterInterface::format
================



FormatterInterface::format — Parses the given $expression and returns its formatted/interpreted version.




Description
================


abstract public [FormatterInterface::format](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Formatter/FormatterInterface/format.md)(string $expression) : string




Parses the given $expression and returns its formatted/interpreted version.




Parameters
================


- expression

    


Return values
================

Returns string.








Source Code
===========
See the source code for method [FormatterInterface::format](https://github.com/lingtalfi/CliTools/blob/master/Formatter/FormatterInterface.php#L23-L23)


See Also
================

The [FormatterInterface](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Formatter/FormatterInterface.md) class.



