[Back to the Ling/CliTools api](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools.md)<br>
[Back to the Ling\CliTools\Util\LoaderUtil class](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/LoaderUtil.md)


LoaderUtil::setDisplayMode
================



LoaderUtil::setDisplayMode — Sets the displayMode.




Description
================


public [LoaderUtil::setDisplayMode](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/LoaderUtil/setDisplayMode.md)(string $displayMode) : void




Sets the displayMode.




Parameters
================


- displayMode

    


Return values
================

Returns void.








Source Code
===========
See the source code for method [LoaderUtil::setDisplayMode](https://github.com/lingtalfi/CliTools/blob/master/Util/LoaderUtil.php#L81-L84)


See Also
================

The [LoaderUtil](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/LoaderUtil.md) class.

Previous method: [setNbTotalItems](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/LoaderUtil/setNbTotalItems.md)<br>Next method: [incrementBy](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/LoaderUtil/incrementBy.md)<br>

