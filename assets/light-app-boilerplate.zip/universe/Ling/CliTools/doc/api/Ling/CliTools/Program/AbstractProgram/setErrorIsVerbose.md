[Back to the Ling/CliTools api](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools.md)<br>
[Back to the Ling\CliTools\Program\AbstractProgram class](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Program/AbstractProgram.md)


AbstractProgram::setErrorIsVerbose
================



AbstractProgram::setErrorIsVerbose — Sets the errorIsVerbose.




Description
================


public [AbstractProgram::setErrorIsVerbose](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Program/AbstractProgram/setErrorIsVerbose.md)(bool $errorIsVerbose) : void




Sets the errorIsVerbose.




Parameters
================


- errorIsVerbose

    


Return values
================

Returns void.








Source Code
===========
See the source code for method [AbstractProgram::setErrorIsVerbose](https://github.com/lingtalfi/CliTools/blob/master/Program/AbstractProgram.php#L129-L132)


See Also
================

The [AbstractProgram](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Program/AbstractProgram.md) class.

Previous method: [setLoggerChannel](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Program/AbstractProgram/setLoggerChannel.md)<br>Next method: [setUseExitStatus](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Program/AbstractProgram/setUseExitStatus.md)<br>

