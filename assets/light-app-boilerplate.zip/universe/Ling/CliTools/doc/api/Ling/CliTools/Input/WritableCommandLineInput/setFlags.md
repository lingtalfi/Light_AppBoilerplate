[Back to the Ling/CliTools api](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools.md)<br>
[Back to the Ling\CliTools\Input\WritableCommandLineInput class](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Input/WritableCommandLineInput.md)


WritableCommandLineInput::setFlags
================



WritableCommandLineInput::setFlags — Sets the flags.




Description
================


public [WritableCommandLineInput::setFlags](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Input/WritableCommandLineInput/setFlags.md)(array $flags) : void




Sets the flags.




Parameters
================


- flags

    


Return values
================

Returns void.








Source Code
===========
See the source code for method [WritableCommandLineInput::setFlags](https://github.com/lingtalfi/CliTools/blob/master/Input/WritableCommandLineInput.php#L17-L20)


See Also
================

The [WritableCommandLineInput](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Input/WritableCommandLineInput.md) class.

Next method: [setOptions](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Input/WritableCommandLineInput/setOptions.md)<br>

