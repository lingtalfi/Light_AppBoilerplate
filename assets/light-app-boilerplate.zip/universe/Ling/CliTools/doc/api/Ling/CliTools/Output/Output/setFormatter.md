[Back to the Ling/CliTools api](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools.md)<br>
[Back to the Ling\CliTools\Output\Output class](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Output/Output.md)


Output::setFormatter
================



Output::setFormatter — Sets the formatter.




Description
================


public [Output::setFormatter](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Output/Output/setFormatter.md)([Ling\CliTools\Formatter\FormatterInterface](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Formatter/FormatterInterface.md) $formatter) : void




Sets the formatter.




Parameters
================


- formatter

    


Return values
================

Returns void.








Source Code
===========
See the source code for method [Output::setFormatter](https://github.com/lingtalfi/CliTools/blob/master/Output/Output.php#L49-L52)


See Also
================

The [Output](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Output/Output.md) class.

Previous method: [__construct](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Output/Output/__construct.md)<br>Next method: [write](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Output/Output/write.md)<br>

