[Back to the Ling/CliTools api](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools.md)<br>
[Back to the Ling\CliTools\Helper\VirginiaMessageHelper class](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Helper/VirginiaMessageHelper.md)


VirginiaMessageHelper::command
================



VirginiaMessageHelper::command — Writes a command message to the output.




Description
================


public static [VirginiaMessageHelper::command](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Helper/VirginiaMessageHelper/command.md)($message, [Ling\CliTools\Output\OutputInterface](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Output/OutputInterface.md) $output, ?int $indent = 0) : void




Writes a command message to the output.




Parameters
================


- message

    

- output

    

- indent

    


Return values
================

Returns void.








Source Code
===========
See the source code for method [VirginiaMessageHelper::command](https://github.com/lingtalfi/CliTools/blob/master/Helper/VirginiaMessageHelper.php#L75-L84)


See Also
================

The [VirginiaMessageHelper](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Helper/VirginiaMessageHelper.md) class.

Previous method: [info](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Helper/VirginiaMessageHelper/info.md)<br>Next method: [warning](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Helper/VirginiaMessageHelper/warning.md)<br>

