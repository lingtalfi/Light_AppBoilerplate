[Back to the Ling/CliTools api](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools.md)<br>
[Back to the Ling\CliTools\Output\BufferedOutput class](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Output/BufferedOutput.md)


BufferedOutput::getMessages
================



BufferedOutput::getMessages — Returns the buffered messages.




Description
================


public [BufferedOutput::getMessages](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Output/BufferedOutput/getMessages.md)() : array




Returns the buffered messages.




Parameters
================

This method has no parameters.


Return values
================

Returns array.
An array of the buffered messages.







Source Code
===========
See the source code for method [BufferedOutput::getMessages](https://github.com/lingtalfi/CliTools/blob/master/Output/BufferedOutput.php#L88-L91)


See Also
================

The [BufferedOutput](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Output/BufferedOutput.md) class.

Previous method: [writeMessages](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Output/BufferedOutput/writeMessages.md)<br>

