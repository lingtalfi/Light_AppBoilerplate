[Back to the Ling/CliTools api](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools.md)<br>
[Back to the Ling\CliTools\Util\LoaderUtil class](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/LoaderUtil.md)


LoaderUtil::setOutput
================



LoaderUtil::setOutput — Sets the output.




Description
================


public [LoaderUtil::setOutput](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/LoaderUtil/setOutput.md)([Ling\CliTools\Output\OutputInterface](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Output/OutputInterface.md) $output) : void




Sets the output.




Parameters
================


- output

    


Return values
================

Returns void.








Source Code
===========
See the source code for method [LoaderUtil::setOutput](https://github.com/lingtalfi/CliTools/blob/master/Util/LoaderUtil.php#L61-L64)


See Also
================

The [LoaderUtil](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/LoaderUtil.md) class.

Previous method: [__construct](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/LoaderUtil/__construct.md)<br>Next method: [setNbTotalItems](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/LoaderUtil/setNbTotalItems.md)<br>

