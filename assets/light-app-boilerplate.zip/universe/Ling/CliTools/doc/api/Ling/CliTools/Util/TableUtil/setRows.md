[Back to the Ling/CliTools api](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools.md)<br>
[Back to the Ling\CliTools\Util\TableUtil class](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/TableUtil.md)


TableUtil::setRows
================



TableUtil::setRows — Sets the rows.




Description
================


public [TableUtil::setRows](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/TableUtil/setRows.md)(array $rows) : void




Sets the rows.




Parameters
================


- rows

    


Return values
================

Returns void.








Source Code
===========
See the source code for method [TableUtil::setRows](https://github.com/lingtalfi/CliTools/blob/master/Util/TableUtil.php#L127-L130)


See Also
================

The [TableUtil](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/TableUtil.md) class.

Previous method: [setOptions](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/TableUtil/setOptions.md)<br>Next method: [render](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/TableUtil/render.md)<br>

