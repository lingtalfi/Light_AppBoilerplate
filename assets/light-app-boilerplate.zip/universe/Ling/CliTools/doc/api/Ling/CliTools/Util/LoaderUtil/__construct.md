[Back to the Ling/CliTools api](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools.md)<br>
[Back to the Ling\CliTools\Util\LoaderUtil class](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/LoaderUtil.md)


LoaderUtil::__construct
================



LoaderUtil::__construct — Builds the LoaderUtil instance.




Description
================


public [LoaderUtil::__construct](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/LoaderUtil/__construct.md)() : void




Builds the LoaderUtil instance.




Parameters
================

This method has no parameters.


Return values
================

Returns void.








Source Code
===========
See the source code for method [LoaderUtil::__construct](https://github.com/lingtalfi/CliTools/blob/master/Util/LoaderUtil.php#L46-L54)


See Also
================

The [LoaderUtil](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/LoaderUtil.md) class.

Next method: [setOutput](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/LoaderUtil/setOutput.md)<br>

