[Back to the Ling/CliTools api](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools.md)<br>
[Back to the Ling\CliTools\Util\LoaderUtil class](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/LoaderUtil.md)


LoaderUtil::incrementBy
================



LoaderUtil::incrementBy — Increments the loader by the given amount.




Description
================


public [LoaderUtil::incrementBy](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/LoaderUtil/incrementBy.md)(?$int = 1) : void




Increments the loader by the given amount.




Parameters
================


- int

    


Return values
================

Returns void.








Source Code
===========
See the source code for method [LoaderUtil::incrementBy](https://github.com/lingtalfi/CliTools/blob/master/Util/LoaderUtil.php#L92-L96)


See Also
================

The [LoaderUtil](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/LoaderUtil.md) class.

Previous method: [setDisplayMode](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/LoaderUtil/setDisplayMode.md)<br>Next method: [start](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Util/LoaderUtil/start.md)<br>

