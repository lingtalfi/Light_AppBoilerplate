[Back to the Ling/CliTools api](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools.md)<br>
[Back to the Ling\CliTools\Input\WritableCommandLineInput class](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Input/WritableCommandLineInput.md)


WritableCommandLineInput::setOptions
================



WritableCommandLineInput::setOptions — Sets the options.




Description
================


public [WritableCommandLineInput::setOptions](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Input/WritableCommandLineInput/setOptions.md)(array $options) : void




Sets the options.




Parameters
================


- options

    


Return values
================

Returns void.








Source Code
===========
See the source code for method [WritableCommandLineInput::setOptions](https://github.com/lingtalfi/CliTools/blob/master/Input/WritableCommandLineInput.php#L27-L30)


See Also
================

The [WritableCommandLineInput](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Input/WritableCommandLineInput.md) class.

Previous method: [setFlags](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Input/WritableCommandLineInput/setFlags.md)<br>Next method: [setParameters](https://github.com/lingtalfi/CliTools/blob/master/doc/api/Ling/CliTools/Input/WritableCommandLineInput/setParameters.md)<br>

