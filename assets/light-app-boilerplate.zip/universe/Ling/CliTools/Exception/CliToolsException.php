<?php


namespace Ling\CliTools\Exception;


/**
 * The base class for all CliTools exceptions.
 */
class CliToolsException extends \Exception
{

}