<?php


namespace Ling\CliTools\Exception;


/**
 * The ApplicationException exception is thrown when a problem occurs in the @object(Application) class.
 *
 */
class ApplicationException extends CliToolsException
{

}