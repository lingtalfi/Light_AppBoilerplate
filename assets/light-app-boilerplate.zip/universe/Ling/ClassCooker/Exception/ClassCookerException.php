<?php


namespace Ling\ClassCooker\Exception;

/**
 * The ClassCookerException class.
 */
class ClassCookerException extends \Exception
{

}