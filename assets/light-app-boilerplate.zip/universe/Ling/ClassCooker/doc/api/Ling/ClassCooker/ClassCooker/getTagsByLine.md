[Back to the Ling/ClassCooker api](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker.md)<br>
[Back to the Ling\ClassCooker\ClassCooker class](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/ClassCooker.md)


ClassCooker::getTagsByLine
================



ClassCooker::getTagsByLine — Returns the tags found in the given line.




Description
================


private [ClassCooker::getTagsByLine](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/ClassCooker/getTagsByLine.md)(string $line) : array




Returns the tags found in the given line.




Parameters
================


- line

    


Return values
================

Returns array.








Source Code
===========
See the source code for method [ClassCooker::getTagsByLine](https://github.com/lingtalfi/ClassCooker/blob/master/ClassCooker.php#L1003-L1012)


See Also
================

The [ClassCooker](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/ClassCooker.md) class.

Previous method: [getLines](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/ClassCooker/getLines.md)<br>Next method: [checkBoundaries](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/ClassCooker/checkBoundaries.md)<br>

