[Back to the Ling/ClassCooker api](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker.md)<br>
[Back to the Ling\ClassCooker\FryingPan\FryingPan class](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/FryingPan.md)


FryingPan::getCooker
================



FryingPan::getCooker — Returns the cooker of this instance.




Description
================


public [FryingPan::getCooker](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/FryingPan/getCooker.md)() : [ClassCooker](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/ClassCooker.md)




Returns the cooker of this instance.




Parameters
================

This method has no parameters.


Return values
================

Returns [ClassCooker](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/ClassCooker.md).








Source Code
===========
See the source code for method [FryingPan::getCooker](https://github.com/lingtalfi/ClassCooker/blob/master/FryingPan/FryingPan.php#L176-L183)


See Also
================

The [FryingPan](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/FryingPan.md) class.

Previous method: [sendToLog](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/FryingPan/sendToLog.md)<br>Next method: [getClassName](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/FryingPan/getClassName.md)<br>

