[Back to the Ling/ClassCooker api](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker.md)<br>
[Back to the Ling\ClassCooker\FryingPan\FryingPan class](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/FryingPan.md)


FryingPan::getLogger
================



FryingPan::getLogger — Returns the logger callable.




Description
================


private [FryingPan::getLogger](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/FryingPan/getLogger.md)() : callable




Returns the logger callable.




Parameters
================

This method has no parameters.


Return values
================

Returns callable.








Source Code
===========
See the source code for method [FryingPan::getLogger](https://github.com/lingtalfi/ClassCooker/blob/master/FryingPan/FryingPan.php#L213-L224)


See Also
================

The [FryingPan](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/FryingPan.md) class.

Previous method: [getClassName](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/FryingPan/getClassName.md)<br>Next method: [error](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/FryingPan/error.md)<br>

