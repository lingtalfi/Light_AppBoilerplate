[Back to the Ling/ClassCooker api](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker.md)<br>
[Back to the Ling\ClassCooker\FryingPan\FryingPan class](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/FryingPan.md)


FryingPan::setFile
================



FryingPan::setFile — Sets the file.




Description
================


public [FryingPan::setFile](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/FryingPan/setFile.md)(string $file) : void




Sets the file.




Parameters
================


- file

    


Return values
================

Returns void.








Source Code
===========
See the source code for method [FryingPan::setFile](https://github.com/lingtalfi/ClassCooker/blob/master/FryingPan/FryingPan.php#L96-L100)


See Also
================

The [FryingPan](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/FryingPan.md) class.

Previous method: [__construct](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/FryingPan/__construct.md)<br>Next method: [getFile](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/FryingPan/getFile.md)<br>

