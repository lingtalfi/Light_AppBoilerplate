[Back to the Ling/ClassCooker api](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker.md)<br>
[Back to the Ling\ClassCooker\FryingPan\FryingPan class](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/FryingPan.md)


FryingPan::getClassName
================



FryingPan::getClassName — Returns the name of the class we're working on.




Description
================


protected [FryingPan::getClassName](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/FryingPan/getClassName.md)() : string




Returns the name of the class we're working on.




Parameters
================

This method has no parameters.


Return values
================

Returns string.








Source Code
===========
See the source code for method [FryingPan::getClassName](https://github.com/lingtalfi/ClassCooker/blob/master/FryingPan/FryingPan.php#L194-L200)


See Also
================

The [FryingPan](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/FryingPan.md) class.

Previous method: [getCooker](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/FryingPan/getCooker.md)<br>Next method: [getLogger](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/FryingPan/getLogger.md)<br>

