[Back to the Ling/ClassCooker api](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker.md)<br>
[Back to the Ling\ClassCooker\Helper\ClassCookerHelper class](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/Helper/ClassCookerHelper.md)


ClassCookerHelper::createSectionComment
================



ClassCookerHelper::createSectionComment — Creates a section comment.




Description
================


public static [ClassCookerHelper::createSectionComment](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/Helper/ClassCookerHelper/createSectionComment.md)($label, ?$tabIndent = 1) : string




Creates a section comment.




Parameters
================


- label

    

- tabIndent

    


Return values
================

Returns string.








Source Code
===========
See the source code for method [ClassCookerHelper::createSectionComment](https://github.com/lingtalfi/ClassCooker/blob/master/Helper/ClassCookerHelper.php#L25-L36)


See Also
================

The [ClassCookerHelper](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/Helper/ClassCookerHelper.md) class.

Next method: [getSectionLineNumber](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/Helper/ClassCookerHelper/getSectionLineNumber.md)<br>

