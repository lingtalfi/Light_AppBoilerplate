[Back to the Ling/ClassCooker api](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker.md)<br>
[Back to the Ling\ClassCooker\FryingPan\FryingPan class](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/FryingPan.md)


FryingPan::setOptions
================



FryingPan::setOptions — Sets the options.




Description
================


public [FryingPan::setOptions](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/FryingPan/setOptions.md)(array $options) : void




Sets the options.




Parameters
================


- options

    


Return values
================

Returns void.








Source Code
===========
See the source code for method [FryingPan::setOptions](https://github.com/lingtalfi/ClassCooker/blob/master/FryingPan/FryingPan.php#L118-L122)


See Also
================

The [FryingPan](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/FryingPan.md) class.

Previous method: [getFile](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/FryingPan/getFile.md)<br>Next method: [addIngredient](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/FryingPan/addIngredient.md)<br>

