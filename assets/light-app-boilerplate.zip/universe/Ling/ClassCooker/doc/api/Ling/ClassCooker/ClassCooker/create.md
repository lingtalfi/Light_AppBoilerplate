[Back to the Ling/ClassCooker api](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker.md)<br>
[Back to the Ling\ClassCooker\ClassCooker class](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/ClassCooker.md)


ClassCooker::create
================



ClassCooker::create — Creates a new instance of this class, and returns it.




Description
================


public static [ClassCooker::create](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/ClassCooker/create.md)() : static




Creates a new instance of this class, and returns it.




Parameters
================

This method has no parameters.


Return values
================

Returns static.








Source Code
===========
See the source code for method [ClassCooker::create](https://github.com/lingtalfi/ClassCooker/blob/master/ClassCooker.php#L34-L37)


See Also
================

The [ClassCooker](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/ClassCooker.md) class.

Next method: [setFile](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/ClassCooker/setFile.md)<br>

