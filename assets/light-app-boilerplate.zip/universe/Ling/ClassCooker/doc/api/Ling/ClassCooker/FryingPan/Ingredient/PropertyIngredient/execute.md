[Back to the Ling/ClassCooker api](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker.md)<br>
[Back to the Ling\ClassCooker\FryingPan\Ingredient\PropertyIngredient class](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/Ingredient/PropertyIngredient.md)


PropertyIngredient::execute
================



PropertyIngredient::execute — Executes the goal of the ingredient.




Description
================


public [PropertyIngredient::execute](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/Ingredient/PropertyIngredient/execute.md)() : void




Executes the goal of the ingredient.




Parameters
================

This method has no parameters.


Return values
================

Returns void.








Source Code
===========
See the source code for method [PropertyIngredient::execute](https://github.com/lingtalfi/ClassCooker/blob/master/FryingPan/Ingredient/PropertyIngredient.php#L24-L48)


See Also
================

The [PropertyIngredient](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/Ingredient/PropertyIngredient.md) class.



