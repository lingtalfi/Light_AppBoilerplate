[Back to the Ling/ClassCooker api](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker.md)<br>
[Back to the Ling\ClassCooker\Helper\ClassCookerHelper class](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/Helper/ClassCookerHelper.md)


ClassCookerHelper::getTagsByLine
================



ClassCookerHelper::getTagsByLine — Returns the tags found in the given line.




Description
================


private static [ClassCookerHelper::getTagsByLine](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/Helper/ClassCookerHelper/getTagsByLine.md)(string $line) : array




Returns the tags found in the given line.




Parameters
================


- line

    


Return values
================

Returns array.








Source Code
===========
See the source code for method [ClassCookerHelper::getTagsByLine](https://github.com/lingtalfi/ClassCooker/blob/master/Helper/ClassCookerHelper.php#L201-L210)


See Also
================

The [ClassCookerHelper](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/Helper/ClassCookerHelper.md) class.

Previous method: [getMethodsBoundaries](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/Helper/ClassCookerHelper/getMethodsBoundaries.md)<br>

