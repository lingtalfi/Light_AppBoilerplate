[Back to the Ling/ClassCooker api](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker.md)



The ClassCookerException class
================
2020-07-21 --> 2020-12-08






Introduction
============

The ClassCookerException class.



Class synopsis
==============


class <span class="pl-k">ClassCookerException</span> extends [\Exception](http://php.net/manual/en/class.exception.php) implements [\Throwable](http://php.net/manual/en/class.throwable.php) {

- Inherited properties
    - protected  [Exception::$message](#property-message) =  ;
    - protected  [Exception::$code](#property-code) = 0 ;
    - protected  [Exception::$file](#property-file) ;
    - protected  [Exception::$line](#property-line) ;

}






Methods
==============






Location
=============
Ling\ClassCooker\Exception\ClassCookerException<br>
See the source code of [Ling\ClassCooker\Exception\ClassCookerException](https://github.com/lingtalfi/ClassCooker/blob/master/Exception/ClassCookerException.php)



SeeAlso
==============
Previous class: [ClassCooker](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/ClassCooker.md)<br>Next class: [FryingPan](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/FryingPan.md)<br>
