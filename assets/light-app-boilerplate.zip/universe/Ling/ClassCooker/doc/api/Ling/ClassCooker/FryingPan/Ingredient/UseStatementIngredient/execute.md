[Back to the Ling/ClassCooker api](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker.md)<br>
[Back to the Ling\ClassCooker\FryingPan\Ingredient\UseStatementIngredient class](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/Ingredient/UseStatementIngredient.md)


UseStatementIngredient::execute
================



UseStatementIngredient::execute — Executes the goal of the ingredient.




Description
================


public [UseStatementIngredient::execute](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/Ingredient/UseStatementIngredient/execute.md)() : void




Executes the goal of the ingredient.




Parameters
================

This method has no parameters.


Return values
================

Returns void.








Source Code
===========
See the source code for method [UseStatementIngredient::execute](https://github.com/lingtalfi/ClassCooker/blob/master/FryingPan/Ingredient/UseStatementIngredient.php#L23-L45)


See Also
================

The [UseStatementIngredient](https://github.com/lingtalfi/ClassCooker/blob/master/doc/api/Ling/ClassCooker/FryingPan/Ingredient/UseStatementIngredient.md) class.



