<?php



use const some\namespace\Ab as MMO;
