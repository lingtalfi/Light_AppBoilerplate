<?php



use function some\namespace\fn_a as Planned;
