<?php



use CC as AZ;

class CC{
}

