<?php



use some\namespace\{TeeParty, function fn_d, const EDM};
