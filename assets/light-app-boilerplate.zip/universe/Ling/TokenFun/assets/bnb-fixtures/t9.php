<?php



use function some\namespace\{fn_b, fn_c};
