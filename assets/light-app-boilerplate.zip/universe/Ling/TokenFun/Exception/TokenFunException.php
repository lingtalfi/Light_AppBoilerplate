<?php


namespace Ling\TokenFun\Exception;

/**
 * The TokenFunException class.
 */
class TokenFunException extends \Exception
{

}