[Back to the Ling/TokenFun api](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun.md)<br>
[Back to the Ling\TokenFun\TokenFinder\RecursiveTokenFinder class](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenFinder/RecursiveTokenFinder.md)


RecursiveTokenFinder::setNestedMode
================



RecursiveTokenFinder::setNestedMode — 




Description
================


public [RecursiveTokenFinder::setNestedMode](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenFinder/RecursiveTokenFinder/setNestedMode.md)(bool $nestedMode) : void




Sets the nested mode




Parameters
================


- nestedMode

    


Return values
================

Returns void.








Source Code
===========
See the source code for method [RecursiveTokenFinder::setNestedMode](https://github.com/lingtalfi/TokenFun/blob/master/TokenFinder/RecursiveTokenFinder.php#L55-L58)


See Also
================

The [RecursiveTokenFinder](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenFinder/RecursiveTokenFinder.md) class.

Previous method: [isNestedMode](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenFinder/RecursiveTokenFinder/isNestedMode.md)<br>Next method: [onMatchFound](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenFinder/RecursiveTokenFinder/onMatchFound.md)<br>

