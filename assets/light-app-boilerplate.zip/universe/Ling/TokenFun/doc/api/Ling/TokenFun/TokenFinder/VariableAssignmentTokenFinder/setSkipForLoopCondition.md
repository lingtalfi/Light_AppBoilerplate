[Back to the Ling/TokenFun api](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun.md)<br>
[Back to the Ling\TokenFun\TokenFinder\VariableAssignmentTokenFinder class](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenFinder/VariableAssignmentTokenFinder.md)


VariableAssignmentTokenFinder::setSkipForLoopCondition
================



VariableAssignmentTokenFinder::setSkipForLoopCondition — Sets the skipForLoopCondition.




Description
================


public [VariableAssignmentTokenFinder::setSkipForLoopCondition](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenFinder/VariableAssignmentTokenFinder/setSkipForLoopCondition.md)(bool $skipForLoopCondition) : void




Sets the skipForLoopCondition.




Parameters
================


- skipForLoopCondition

    


Return values
================

Returns void.








Source Code
===========
See the source code for method [VariableAssignmentTokenFinder::setSkipForLoopCondition](https://github.com/lingtalfi/TokenFun/blob/master/TokenFinder/VariableAssignmentTokenFinder.php#L371-L374)


See Also
================

The [VariableAssignmentTokenFinder](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenFinder/VariableAssignmentTokenFinder.md) class.

Previous method: [isSkipForLoopCondition](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenFinder/VariableAssignmentTokenFinder/isSkipForLoopCondition.md)<br>Next method: [isSkipControlStructure](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenFinder/VariableAssignmentTokenFinder/isSkipControlStructure.md)<br>

