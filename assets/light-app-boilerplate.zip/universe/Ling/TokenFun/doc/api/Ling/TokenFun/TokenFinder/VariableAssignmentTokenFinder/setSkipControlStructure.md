[Back to the Ling/TokenFun api](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun.md)<br>
[Back to the Ling\TokenFun\TokenFinder\VariableAssignmentTokenFinder class](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenFinder/VariableAssignmentTokenFinder.md)


VariableAssignmentTokenFinder::setSkipControlStructure
================



VariableAssignmentTokenFinder::setSkipControlStructure — Sets the skipControlStructure.




Description
================


public [VariableAssignmentTokenFinder::setSkipControlStructure](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenFinder/VariableAssignmentTokenFinder/setSkipControlStructure.md)(bool $skipControlStructure) : void




Sets the skipControlStructure.




Parameters
================


- skipControlStructure

    


Return values
================

Returns void.








Source Code
===========
See the source code for method [VariableAssignmentTokenFinder::setSkipControlStructure](https://github.com/lingtalfi/TokenFun/blob/master/TokenFinder/VariableAssignmentTokenFinder.php#L391-L394)


See Also
================

The [VariableAssignmentTokenFinder](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenFinder/VariableAssignmentTokenFinder.md) class.

Previous method: [isSkipControlStructure](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenFinder/VariableAssignmentTokenFinder/isSkipControlStructure.md)<br>Next method: [isAllowArrayAffectation](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenFinder/VariableAssignmentTokenFinder/isAllowArrayAffectation.md)<br>

