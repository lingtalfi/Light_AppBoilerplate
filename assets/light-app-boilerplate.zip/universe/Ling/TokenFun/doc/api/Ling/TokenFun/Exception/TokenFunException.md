[Back to the Ling/TokenFun api](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun.md)



The TokenFunException class
================
2020-07-28 --> 2021-02-02






Introduction
============

The TokenFunException class.



Class synopsis
==============


class <span class="pl-k">TokenFunException</span> extends [\Exception](http://php.net/manual/en/class.exception.php) implements [\Stringable](https://wiki.php.net/rfc/stringable), [\Throwable](http://php.net/manual/en/class.throwable.php) {

- Inherited properties
    - protected  [Exception::$message](#property-message) =  ;
    - protected  [Exception::$code](#property-code) = 0 ;
    - protected  [Exception::$file](#property-file) ;
    - protected  [Exception::$line](#property-line) ;

}






Methods
==============






Location
=============
Ling\TokenFun\Exception\TokenFunException<br>
See the source code of [Ling\TokenFun\Exception\TokenFunException](https://github.com/lingtalfi/TokenFun/blob/master/Exception/TokenFunException.php)



SeeAlso
==============
Next class: [TokenArrayIterator](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenArrayIterator/TokenArrayIterator.md)<br>
