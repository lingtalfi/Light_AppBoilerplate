[Back to the Ling/TokenFun api](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun.md)<br>
[Back to the Ling\TokenFun\TokenArrayIterator\TokenArrayIterator class](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenArrayIterator/TokenArrayIterator.md)


TokenArrayIterator::getArray
================



TokenArrayIterator::getArray — Returns the inner array.




Description
================


public [TokenArrayIterator::getArray](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenArrayIterator/TokenArrayIterator/getArray.md)() : array




Returns the inner array.




Parameters
================

This method has no parameters.


Return values
================

Returns array.








Source Code
===========
See the source code for method [TokenArrayIterator::getArray](https://github.com/lingtalfi/TokenFun/blob/master/TokenArrayIterator/TokenArrayIterator.php#L110-L113)


See Also
================

The [TokenArrayIterator](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenArrayIterator/TokenArrayIterator.md) class.

Previous method: [seek](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenArrayIterator/TokenArrayIterator/seek.md)<br>Next method: [dump](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenArrayIterator/TokenArrayIterator/dump.md)<br>

