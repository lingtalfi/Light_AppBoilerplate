[Back to the Ling/TokenFun api](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun.md)<br>
[Back to the Ling\TokenFun\TokenArrayIterator\TokenArrayIterator class](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenArrayIterator/TokenArrayIterator.md)


TokenArrayIterator::__construct
================



TokenArrayIterator::__construct — Builds the TokenArrayIterator instance.




Description
================


public [TokenArrayIterator::__construct](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenArrayIterator/TokenArrayIterator/__construct.md)(array $array) : void




Builds the TokenArrayIterator instance.




Parameters
================


- array

    


Return values
================

Returns void.








Source Code
===========
See the source code for method [TokenArrayIterator::__construct](https://github.com/lingtalfi/TokenFun/blob/master/TokenArrayIterator/TokenArrayIterator.php#L28-L31)


See Also
================

The [TokenArrayIterator](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenArrayIterator/TokenArrayIterator.md) class.

Next method: [key](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenArrayIterator/TokenArrayIterator/key.md)<br>

