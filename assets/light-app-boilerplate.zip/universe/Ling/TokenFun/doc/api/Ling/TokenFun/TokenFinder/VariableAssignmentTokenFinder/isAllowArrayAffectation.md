[Back to the Ling/TokenFun api](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun.md)<br>
[Back to the Ling\TokenFun\TokenFinder\VariableAssignmentTokenFinder class](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenFinder/VariableAssignmentTokenFinder.md)


VariableAssignmentTokenFinder::isAllowArrayAffectation
================



VariableAssignmentTokenFinder::isAllowArrayAffectation — Returns the allowArrayAffectation of this instance.




Description
================


public [VariableAssignmentTokenFinder::isAllowArrayAffectation](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenFinder/VariableAssignmentTokenFinder/isAllowArrayAffectation.md)() : bool




Returns the allowArrayAffectation of this instance.




Parameters
================

This method has no parameters.


Return values
================

Returns bool.








Source Code
===========
See the source code for method [VariableAssignmentTokenFinder::isAllowArrayAffectation](https://github.com/lingtalfi/TokenFun/blob/master/TokenFinder/VariableAssignmentTokenFinder.php#L401-L404)


See Also
================

The [VariableAssignmentTokenFinder](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenFinder/VariableAssignmentTokenFinder.md) class.

Previous method: [setSkipControlStructure](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenFinder/VariableAssignmentTokenFinder/setSkipControlStructure.md)<br>Next method: [setAllowArrayAffectation](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenFinder/VariableAssignmentTokenFinder/setAllowArrayAffectation.md)<br>

