[Back to the Ling/TokenFun api](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun.md)<br>
[Back to the Ling\TokenFun\TokenFinder\VariableAssignmentTokenFinder class](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenFinder/VariableAssignmentTokenFinder.md)


VariableAssignmentTokenFinder::setAllowArrayAffectation
================



VariableAssignmentTokenFinder::setAllowArrayAffectation — Sets the allowArrayAffectation.




Description
================


public [VariableAssignmentTokenFinder::setAllowArrayAffectation](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenFinder/VariableAssignmentTokenFinder/setAllowArrayAffectation.md)(bool $allowArrayAffectation) : void




Sets the allowArrayAffectation.




Parameters
================


- allowArrayAffectation

    


Return values
================

Returns void.








Source Code
===========
See the source code for method [VariableAssignmentTokenFinder::setAllowArrayAffectation](https://github.com/lingtalfi/TokenFun/blob/master/TokenFinder/VariableAssignmentTokenFinder.php#L411-L414)


See Also
================

The [VariableAssignmentTokenFinder](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenFinder/VariableAssignmentTokenFinder.md) class.

Previous method: [isAllowArrayAffectation](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenFinder/VariableAssignmentTokenFinder/isAllowArrayAffectation.md)<br>Next method: [isAllowDynamic](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenFinder/VariableAssignmentTokenFinder/isAllowDynamic.md)<br>

