[Back to the Ling/TokenFun api](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun.md)<br>
[Back to the Ling\TokenFun\TokenArrayIterator\TokenArrayIteratorInterface class](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenArrayIterator/TokenArrayIteratorInterface.md)


TokenArrayIteratorInterface::getArray
================



TokenArrayIteratorInterface::getArray — Returns the inner array.




Description
================


abstract public [TokenArrayIteratorInterface::getArray](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenArrayIterator/TokenArrayIteratorInterface/getArray.md)() : array




Returns the inner array.




Parameters
================

This method has no parameters.


Return values
================

Returns array.








Source Code
===========
See the source code for method [TokenArrayIteratorInterface::getArray](https://github.com/lingtalfi/TokenFun/blob/master/TokenArrayIterator/TokenArrayIteratorInterface.php#L70-L70)


See Also
================

The [TokenArrayIteratorInterface](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenArrayIterator/TokenArrayIteratorInterface.md) class.

Previous method: [seek](https://github.com/lingtalfi/TokenFun/blob/master/doc/api/Ling/TokenFun/TokenArrayIterator/TokenArrayIteratorInterface/seek.md)<br>

