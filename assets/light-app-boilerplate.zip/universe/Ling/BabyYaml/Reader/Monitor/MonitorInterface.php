<?php


namespace Ling\BabyYaml\Reader\Monitor;


/**
 * MonitorInterface
 * @author Lingtalfi
 * 2015-05-07
 *
 */
interface MonitorInterface
{

    public function say($msg, $tags = null);
}
