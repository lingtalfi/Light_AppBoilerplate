<?php


namespace Ling\BabyYaml\Reader\MiniMl\Formatter;


/**
 * MiniMlFormatterInterface
 * @author Lingtalfi
 * 2015-05-21
 *
 */
interface MiniMlFormatterInterface
{

    public function format($string);
}
