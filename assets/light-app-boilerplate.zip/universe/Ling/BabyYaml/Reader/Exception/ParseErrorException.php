<?php


namespace Ling\BabyYaml\Reader\Exception;


use Ling\BabyYaml\Exception\BabyYamlException;

class ParseErrorException extends BabyYamlException
{

}