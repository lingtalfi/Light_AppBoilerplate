<?php


namespace Ling\BabyYaml\Helper;


/**
 * IntTool
 * @author Lingtalfi
 * 2015-05-17
 *
 */
class IntTool
{

    public static function isEven($n)
    {
        return ($n % 2 == 0);
    }
}
