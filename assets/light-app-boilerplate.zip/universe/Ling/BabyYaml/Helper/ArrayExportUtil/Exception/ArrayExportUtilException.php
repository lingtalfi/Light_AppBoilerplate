<?php


namespace Ling\BabyYaml\Helper\ArrayExportUtil\Exception;



/**
 * ArrayExportUtilExceptionAZBV!FGHYIOÇPOÀ)À CDZEFGFAZ&@A
 * @author Lingtalfi
 * 2015-05-27
 * 
 */
class ArrayExportUtilException extends \Exception{

}
