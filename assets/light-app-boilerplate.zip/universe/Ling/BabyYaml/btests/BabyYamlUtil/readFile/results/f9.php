<?php


$defs = [
    'doo' => null,
    'but' => '',
    'true' => true,
    'false' => false,
    'int' => 64,
    'float' => 6.4,
];