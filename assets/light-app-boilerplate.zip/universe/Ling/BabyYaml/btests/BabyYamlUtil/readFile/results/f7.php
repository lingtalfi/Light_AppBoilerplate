<?php


$defs = [
    'doo' => 'no worries',
];