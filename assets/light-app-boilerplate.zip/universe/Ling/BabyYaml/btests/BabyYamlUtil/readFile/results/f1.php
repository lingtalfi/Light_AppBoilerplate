<?php


$defs = [
    'doo',
    'foo',
];