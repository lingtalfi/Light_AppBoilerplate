<?php


$defs = [
    'doo' => null,
    'but' => '',
    'true' => true,
    'false' => "ji # not a comment",
    'dup' => "ji",
    'arr' => ['soo'],
];