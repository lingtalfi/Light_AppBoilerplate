[Back to the Ling/SicTools api](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools.md)<br>
[Back to the Ling\SicTools\Util\SicFileCombinerUtil class](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/Util/SicFileCombinerUtil.md)


SicFileCombinerUtil::setLazyOverrideSymbol
================



SicFileCombinerUtil::setLazyOverrideSymbol — Sets the lazyOverrideSymbol.




Description
================


public [SicFileCombinerUtil::setLazyOverrideSymbol](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/Util/SicFileCombinerUtil/setLazyOverrideSymbol.md)(string $lazyOverrideSymbol) : void




Sets the lazyOverrideSymbol.




Parameters
================


- lazyOverrideSymbol

    


Return values
================

Returns void.








Source Code
===========
See the source code for method [SicFileCombinerUtil::setLazyOverrideSymbol](https://github.com/lingtalfi/SicTools/blob/master/Util/SicFileCombinerUtil.php#L319-L322)


See Also
================

The [SicFileCombinerUtil](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/Util/SicFileCombinerUtil.md) class.

Previous method: [__construct](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/Util/SicFileCombinerUtil/__construct.md)<br>Next method: [setVariableSymbol](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/Util/SicFileCombinerUtil/setVariableSymbol.md)<br>

