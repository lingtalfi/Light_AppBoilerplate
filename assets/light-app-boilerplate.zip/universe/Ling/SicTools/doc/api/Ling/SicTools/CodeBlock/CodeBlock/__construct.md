[Back to the Ling/SicTools api](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools.md)<br>
[Back to the Ling\SicTools\CodeBlock\CodeBlock class](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/CodeBlock/CodeBlock.md)


CodeBlock::__construct
================



CodeBlock::__construct — Builds the CodeBlock instance.




Description
================


public [CodeBlock::__construct](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/CodeBlock/CodeBlock/__construct.md)() : void




Builds the CodeBlock instance.




Parameters
================

This method has no parameters.


Return values
================

Returns void.








Source Code
===========
See the source code for method [CodeBlock::__construct](https://github.com/lingtalfi/SicTools/blob/master/CodeBlock/CodeBlock.php#L23-L26)


See Also
================

The [CodeBlock](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/CodeBlock/CodeBlock.md) class.

Next method: [addStatement](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/CodeBlock/CodeBlock/addStatement.md)<br>

