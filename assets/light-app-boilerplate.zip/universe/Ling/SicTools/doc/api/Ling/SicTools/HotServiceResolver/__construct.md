[Back to the Ling/SicTools api](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools.md)<br>
[Back to the Ling\SicTools\HotServiceResolver class](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/HotServiceResolver.md)


HotServiceResolver::__construct
================



HotServiceResolver::__construct — Builds the HotServiceResolver instance.




Description
================


public [HotServiceResolver::__construct](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/HotServiceResolver/__construct.md)() : void




Builds the HotServiceResolver instance.




Parameters
================

This method has no parameters.


Return values
================

Returns void.








Source Code
===========
See the source code for method [HotServiceResolver::__construct](https://github.com/lingtalfi/SicTools/blob/master/HotServiceResolver.php#L40-L43)


See Also
================

The [HotServiceResolver](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/HotServiceResolver.md) class.

Next method: [getService](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/HotServiceResolver/getService.md)<br>

