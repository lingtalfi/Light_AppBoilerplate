[Back to the Ling/SicTools api](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools.md)<br>
[Back to the Ling\SicTools\ColdServiceResolver class](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/ColdServiceResolver.md)


ColdServiceResolver::__construct
================



ColdServiceResolver::__construct — Builds the ColdServiceResolver instance.




Description
================


public [ColdServiceResolver::__construct](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/ColdServiceResolver/__construct.md)() : void




Builds the ColdServiceResolver instance.




Parameters
================

This method has no parameters.


Return values
================

Returns void.








Source Code
===========
See the source code for method [ColdServiceResolver::__construct](https://github.com/lingtalfi/SicTools/blob/master/ColdServiceResolver.php#L64-L70)


See Also
================

The [ColdServiceResolver](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/ColdServiceResolver.md) class.

Next method: [getServicePhpCode](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/ColdServiceResolver/getServicePhpCode.md)<br>

