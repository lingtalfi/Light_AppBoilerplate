[Back to the Ling/SicTools api](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools.md)<br>
[Back to the Ling\SicTools\Util\SicFileCombinerUtil class](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/Util/SicFileCombinerUtil.md)


SicFileCombinerUtil::setVariableSymbol
================



SicFileCombinerUtil::setVariableSymbol — Sets the variableSymbol.




Description
================


public [SicFileCombinerUtil::setVariableSymbol](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/Util/SicFileCombinerUtil/setVariableSymbol.md)(string $variableSymbol) : void




Sets the variableSymbol.




Parameters
================


- variableSymbol

    


Return values
================

Returns void.








Source Code
===========
See the source code for method [SicFileCombinerUtil::setVariableSymbol](https://github.com/lingtalfi/SicTools/blob/master/Util/SicFileCombinerUtil.php#L329-L332)


See Also
================

The [SicFileCombinerUtil](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/Util/SicFileCombinerUtil.md) class.

Previous method: [setLazyOverrideSymbol](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/Util/SicFileCombinerUtil/setLazyOverrideSymbol.md)<br>Next method: [setEnvironmentVariables](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/Util/SicFileCombinerUtil/setEnvironmentVariables.md)<br>

