[Back to the Ling/SicTools api](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools.md)<br>
[Back to the Ling\SicTools\Util\SicFileCombinerUtil class](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/Util/SicFileCombinerUtil.md)


SicFileCombinerUtil::setEnvironmentVariables
================



SicFileCombinerUtil::setEnvironmentVariables — Sets the environmentVariables.




Description
================


public [SicFileCombinerUtil::setEnvironmentVariables](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/Util/SicFileCombinerUtil/setEnvironmentVariables.md)(array $environmentVariables) : [SicFileCombinerUtil](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/Util/SicFileCombinerUtil.md)




Sets the environmentVariables.




Parameters
================


- environmentVariables

    


Return values
================

Returns [SicFileCombinerUtil](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/Util/SicFileCombinerUtil.md).








Source Code
===========
See the source code for method [SicFileCombinerUtil::setEnvironmentVariables](https://github.com/lingtalfi/SicTools/blob/master/Util/SicFileCombinerUtil.php#L340-L344)


See Also
================

The [SicFileCombinerUtil](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/Util/SicFileCombinerUtil.md) class.

Previous method: [setVariableSymbol](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/Util/SicFileCombinerUtil/setVariableSymbol.md)<br>Next method: [combine](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/Util/SicFileCombinerUtil/combine.md)<br>

