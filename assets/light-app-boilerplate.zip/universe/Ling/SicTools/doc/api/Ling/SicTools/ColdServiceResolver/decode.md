[Back to the Ling/SicTools api](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools.md)<br>
[Back to the Ling\SicTools\ColdServiceResolver class](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/ColdServiceResolver.md)


ColdServiceResolver::decode
================



ColdServiceResolver::decode — Decodes the encoded expression and returns the result.




Description
================


protected [ColdServiceResolver::decode](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/ColdServiceResolver/decode.md)(string $expression) : string




Decodes the encoded expression and returns the result.




Parameters
================


- expression

    


Return values
================

Returns string.








Source Code
===========
See the source code for method [ColdServiceResolver::decode](https://github.com/lingtalfi/SicTools/blob/master/ColdServiceResolver.php#L351-L354)


See Also
================

The [ColdServiceResolver](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/ColdServiceResolver.md) class.

Previous method: [encode](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/ColdServiceResolver/encode.md)<br>Next method: [getUniqueVariableName](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/ColdServiceResolver/getUniqueVariableName.md)<br>

