[Back to the Ling/SicTools api](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools.md)<br>
[Back to the Ling\SicTools\Util\SicFileCombinerUtil class](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/Util/SicFileCombinerUtil.md)


SicFileCombinerUtil::__construct
================



SicFileCombinerUtil::__construct — Builds the SicFileCombinerUtil instance.




Description
================


public [SicFileCombinerUtil::__construct](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/Util/SicFileCombinerUtil/__construct.md)() : void




Builds the SicFileCombinerUtil instance.




Parameters
================

This method has no parameters.


Return values
================

Returns void.








Source Code
===========
See the source code for method [SicFileCombinerUtil::__construct](https://github.com/lingtalfi/SicTools/blob/master/Util/SicFileCombinerUtil.php#L307-L312)


See Also
================

The [SicFileCombinerUtil](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/Util/SicFileCombinerUtil.md) class.

Next method: [setLazyOverrideSymbol](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/Util/SicFileCombinerUtil/setLazyOverrideSymbol.md)<br>

