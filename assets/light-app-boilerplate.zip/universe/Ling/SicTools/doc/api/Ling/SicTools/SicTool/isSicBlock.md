[Back to the Ling/SicTools api](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools.md)<br>
[Back to the Ling\SicTools\SicTool class](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/SicTool.md)


SicTool::isSicBlock
================



SicTool::isSicBlock — Returns whether the given $thing is a sic block.




Description
================


public static [SicTool::isSicBlock](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/SicTool/isSicBlock.md)($thing, ?$passKey = null) : bool




Returns whether the given $thing is a sic block.




Parameters
================


- thing

    

- passKey

    


Return values
================

Returns bool.








Source Code
===========
See the source code for method [SicTool::isSicBlock](https://github.com/lingtalfi/SicTools/blob/master/SicTool.php#L24-L37)


See Also
================

The [SicTool](https://github.com/lingtalfi/SicTools/blob/master/doc/api/Ling/SicTools/SicTool.md) class.



