<?php

namespace Ling\SicTools\Exception;


/**
 * The SicToolsException class is the base class for all exceptions of the SicTools planet.
 *
 */
class SicToolsException extends \Exception
{

}