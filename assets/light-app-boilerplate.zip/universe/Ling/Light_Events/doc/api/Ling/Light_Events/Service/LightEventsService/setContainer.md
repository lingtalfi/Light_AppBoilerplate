[Back to the Ling/Light_Events api](https://github.com/lingtalfi/Light_Events/blob/master/doc/api/Ling/Light_Events.md)<br>
[Back to the Ling\Light_Events\Service\LightEventsService class](https://github.com/lingtalfi/Light_Events/blob/master/doc/api/Ling/Light_Events/Service/LightEventsService.md)


LightEventsService::setContainer
================



LightEventsService::setContainer — Sets the container.




Description
================


public [LightEventsService::setContainer](https://github.com/lingtalfi/Light_Events/blob/master/doc/api/Ling/Light_Events/Service/LightEventsService/setContainer.md)([Ling\Light\ServiceContainer\LightServiceContainerInterface](https://github.com/lingtalfi/Light/blob/master/doc/api/Ling/Light/ServiceContainer/LightServiceContainerInterface.md) $container) : void




Sets the container.




Parameters
================


- container

    


Return values
================

Returns void.








Source Code
===========
See the source code for method [LightEventsService::setContainer](https://github.com/lingtalfi/Light_Events/blob/master/Service/LightEventsService.php#L227-L230)


See Also
================

The [LightEventsService](https://github.com/lingtalfi/Light_Events/blob/master/doc/api/Ling/Light_Events/Service/LightEventsService.md) class.

Previous method: [getDispatchedEvents](https://github.com/lingtalfi/Light_Events/blob/master/doc/api/Ling/Light_Events/Service/LightEventsService/getDispatchedEvents.md)<br>Next method: [setOptions](https://github.com/lingtalfi/Light_Events/blob/master/doc/api/Ling/Light_Events/Service/LightEventsService/setOptions.md)<br>

