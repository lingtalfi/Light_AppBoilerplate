[Back to the Ling/Light_Events api](https://github.com/lingtalfi/Light_Events/blob/master/doc/api/Ling/Light_Events.md)



The LightEventsException class
================
2019-10-31 --> 2021-01-11






Introduction
============

The LightEventsException class.



Class synopsis
==============


class <span class="pl-k">LightEventsException</span> extends [\Exception](http://php.net/manual/en/class.exception.php) implements [\Throwable](http://php.net/manual/en/class.throwable.php) {

- Inherited properties
    - protected  [Exception::$message](#property-message) =  ;
    - protected  [Exception::$code](#property-code) = 0 ;
    - protected  [Exception::$file](#property-file) ;
    - protected  [Exception::$line](#property-line) ;

}






Methods
==============






Location
=============
Ling\Light_Events\Exception\LightEventsException<br>
See the source code of [Ling\Light_Events\Exception\LightEventsException](https://github.com/lingtalfi/Light_Events/blob/master/Exception/LightEventsException.php)



SeeAlso
==============
Next class: [LightEventsHelper](https://github.com/lingtalfi/Light_Events/blob/master/doc/api/Ling/Light_Events/Helper/LightEventsHelper.md)<br>
