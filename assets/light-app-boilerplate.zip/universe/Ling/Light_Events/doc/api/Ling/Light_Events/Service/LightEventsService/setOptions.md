[Back to the Ling/Light_Events api](https://github.com/lingtalfi/Light_Events/blob/master/doc/api/Ling/Light_Events.md)<br>
[Back to the Ling\Light_Events\Service\LightEventsService class](https://github.com/lingtalfi/Light_Events/blob/master/doc/api/Ling/Light_Events/Service/LightEventsService.md)


LightEventsService::setOptions
================



LightEventsService::setOptions — Sets the options.




Description
================


public [LightEventsService::setOptions](https://github.com/lingtalfi/Light_Events/blob/master/doc/api/Ling/Light_Events/Service/LightEventsService/setOptions.md)(array $options) : void




Sets the options.




Parameters
================


- options

    


Return values
================

Returns void.








Source Code
===========
See the source code for method [LightEventsService::setOptions](https://github.com/lingtalfi/Light_Events/blob/master/Service/LightEventsService.php#L237-L240)


See Also
================

The [LightEventsService](https://github.com/lingtalfi/Light_Events/blob/master/doc/api/Ling/Light_Events/Service/LightEventsService.md) class.

Previous method: [setContainer](https://github.com/lingtalfi/Light_Events/blob/master/doc/api/Ling/Light_Events/Service/LightEventsService/setContainer.md)<br>Next method: [onListenerProcessBefore](https://github.com/lingtalfi/Light_Events/blob/master/doc/api/Ling/Light_Events/Service/LightEventsService/onListenerProcessBefore.md)<br>

