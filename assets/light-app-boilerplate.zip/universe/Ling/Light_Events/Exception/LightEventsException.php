<?php


namespace Ling\Light_Events\Exception;


/**
 * The LightEventsException class.
 */
class LightEventsException extends \Exception
{

}