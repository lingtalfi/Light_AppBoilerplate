<?php


namespace Ling\SimplePdoWrapper\Exception;


/**
 * The SimplePdoWrapperException class is the base exception class for all SimplePdoWrapper exceptions.
 */
class SimplePdoWrapperException extends \Exception
{

}