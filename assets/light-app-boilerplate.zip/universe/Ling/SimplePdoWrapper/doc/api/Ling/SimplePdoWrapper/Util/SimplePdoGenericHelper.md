[Back to the Ling/SimplePdoWrapper api](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper.md)



The SimplePdoGenericHelper class
================
2019-07-22 --> 2020-12-08






Introduction
============

The SimplePdoGenericHelper class.



Class synopsis
==============


class <span class="pl-k">SimplePdoGenericHelper</span>  {

- Methods
    - public static [getUniqueIdentifier](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Util/SimplePdoGenericHelper/getUniqueIdentifier.md)(?string $prefix = null) : string

}






Methods
==============

- [SimplePdoGenericHelper::getUniqueIdentifier](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Util/SimplePdoGenericHelper/getUniqueIdentifier.md) &ndash; Returns a unique identifier.





Location
=============
Ling\SimplePdoWrapper\Util\SimplePdoGenericHelper<br>
See the source code of [Ling\SimplePdoWrapper\Util\SimplePdoGenericHelper](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/Util/SimplePdoGenericHelper.php)



SeeAlso
==============
Previous class: [RicHelper](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Util/RicHelper.md)<br>Next class: [SimplePdoSpecialExpressionHelper](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Util/SimplePdoSpecialExpressionHelper.md)<br>
