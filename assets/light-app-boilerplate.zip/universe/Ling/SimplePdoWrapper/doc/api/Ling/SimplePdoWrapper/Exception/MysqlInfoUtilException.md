[Back to the Ling/SimplePdoWrapper api](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper.md)



The MysqlInfoUtilException class
================
2019-07-22 --> 2021-03-05






Introduction
============

The MysqlInfoUtilException class.



Class synopsis
==============


class <span class="pl-k">MysqlInfoUtilException</span> extends [SimplePdoWrapperException](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Exception/SimplePdoWrapperException.md) implements [\Throwable](http://php.net/manual/en/class.throwable.php), [\Stringable](https://wiki.php.net/rfc/stringable) {

- Inherited properties
    - protected  [Exception::$message](#property-message) =  ;
    - protected  [Exception::$code](#property-code) = 0 ;
    - protected  [Exception::$file](#property-file) ;
    - protected  [Exception::$line](#property-line) ;

}






Methods
==============






Location
=============
Ling\SimplePdoWrapper\Exception\MysqlInfoUtilException<br>
See the source code of [Ling\SimplePdoWrapper\Exception\MysqlInfoUtilException](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/Exception/MysqlInfoUtilException.php)



SeeAlso
==============
Previous class: [InvalidTableNameException](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Exception/InvalidTableNameException.md)<br>Next class: [NoPdoConnectionException](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Exception/NoPdoConnectionException.md)<br>
