[Back to the Ling/SimplePdoWrapper api](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper.md)<br>
[Back to the Ling\SimplePdoWrapper\Exception\SimplePdoWrapperQueryException class](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Exception/SimplePdoWrapperQueryException.md)


SimplePdoWrapperQueryException::__construct
================



SimplePdoWrapperQueryException::__construct — Builds the SimplePdoWrapperQueryException instance.




Description
================


public [SimplePdoWrapperQueryException::__construct](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Exception/SimplePdoWrapperQueryException/__construct.md)(?$message = , ?$code = 0, ?[\Throwable](http://php.net/manual/en/class.throwable.php) $previous = null) : void




Builds the SimplePdoWrapperQueryException instance.




Parameters
================


- message

    

- code

    

- previous

    


Return values
================

Returns void.








Source Code
===========
See the source code for method [SimplePdoWrapperQueryException::__construct](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/Exception/SimplePdoWrapperQueryException.php#L29-L32)


See Also
================

The [SimplePdoWrapperQueryException](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Exception/SimplePdoWrapperQueryException.md) class.

Next method: [getQuery](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Exception/SimplePdoWrapperQueryException/getQuery.md)<br>

