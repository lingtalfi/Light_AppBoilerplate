[Back to the Ling/SimplePdoWrapper api](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper.md)<br>
[Back to the Ling\SimplePdoWrapper\Util\Limit class](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Util/Limit.md)


Limit::getOffset
================



Limit::getOffset — Returns the offset of this instance.




Description
================


public [Limit::getOffset](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Util/Limit/getOffset.md)() : int




Returns the offset of this instance.




Parameters
================

This method has no parameters.


Return values
================

Returns int.








Source Code
===========
See the source code for method [Limit::getOffset](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/Util/Limit.php#L91-L94)


See Also
================

The [Limit](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Util/Limit.md) class.

Previous method: [apply](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Util/Limit/apply.md)<br>Next method: [getRowCount](https://github.com/lingtalfi/SimplePdoWrapper/blob/master/doc/api/Ling/SimplePdoWrapper/Util/Limit/getRowCount.md)<br>

