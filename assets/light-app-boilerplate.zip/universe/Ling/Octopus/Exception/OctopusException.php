<?php


namespace Ling\Octopus\Exception;


/**
 * The OctopusException class is the base class for Octopus exceptions.
 */
class OctopusException extends \Exception
{

}