[Back to the Ling/CyclicChainDetector api](https://github.com/lingtalfi/CyclicChainDetector/blob/master/doc/api/Ling/CyclicChainDetector.md)<br>
[Back to the Ling\CyclicChainDetector\Helper\CyclicChainDetectorHelper class](https://github.com/lingtalfi/CyclicChainDetector/blob/master/doc/api/Ling/CyclicChainDetector/Helper/CyclicChainDetectorHelper.md)


CyclicChainDetectorHelper::debugLinks
================



CyclicChainDetectorHelper::debugLinks — Prints a human readable version of the links contained in the given chain.




Description
================


public static [CyclicChainDetectorHelper::debugLinks](https://github.com/lingtalfi/CyclicChainDetector/blob/master/doc/api/Ling/CyclicChainDetector/Helper/CyclicChainDetectorHelper/debugLinks.md)([Ling\CyclicChainDetector\CyclicChainDetectorUtil](https://github.com/lingtalfi/CyclicChainDetector/blob/master/doc/api/Ling/CyclicChainDetector/CyclicChainDetectorUtil.md) $util) : void




Prints a human readable version of the links contained in the given chain.




Parameters
================


- util

    


Return values
================

Returns void.








Source Code
===========
See the source code for method [CyclicChainDetectorHelper::debugLinks](https://github.com/lingtalfi/CyclicChainDetector/blob/master/Helper/CyclicChainDetectorHelper.php#L22-L35)


See Also
================

The [CyclicChainDetectorHelper](https://github.com/lingtalfi/CyclicChainDetector/blob/master/doc/api/Ling/CyclicChainDetector/Helper/CyclicChainDetectorHelper.md) class.

Next method: [debugLink](https://github.com/lingtalfi/CyclicChainDetector/blob/master/doc/api/Ling/CyclicChainDetector/Helper/CyclicChainDetectorHelper/debugLink.md)<br>

