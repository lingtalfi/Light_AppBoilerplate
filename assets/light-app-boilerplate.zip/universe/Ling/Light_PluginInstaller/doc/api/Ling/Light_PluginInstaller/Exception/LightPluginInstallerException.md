[Back to the Ling/Light_PluginInstaller api](https://github.com/lingtalfi/Light_PluginInstaller/blob/master/doc/api/Ling/Light_PluginInstaller.md)



The LightPluginInstallerException class
================
2020-02-07 --> 2021-05-03






Introduction
============

The LightPluginInstallerException class.



Class synopsis
==============


class <span class="pl-k">LightPluginInstallerException</span> extends [\Exception](http://php.net/manual/en/class.exception.php) implements [\Stringable](https://wiki.php.net/rfc/stringable), [\Throwable](http://php.net/manual/en/class.throwable.php) {

- Inherited properties
    - protected  [Exception::$message](#property-message) =  ;
    - protected  [Exception::$code](#property-code) = 0 ;
    - protected  [Exception::$file](#property-file) ;
    - protected  [Exception::$line](#property-line) ;

}






Methods
==============






Location
=============
Ling\Light_PluginInstaller\Exception\LightPluginInstallerException<br>
See the source code of [Ling\Light_PluginInstaller\Exception\LightPluginInstallerException](https://github.com/lingtalfi/Light_PluginInstaller/blob/master/Exception/LightPluginInstallerException.php)



SeeAlso
==============
Next class: [PluginInstallerInterface](https://github.com/lingtalfi/Light_PluginInstaller/blob/master/doc/api/Ling/Light_PluginInstaller/PluginInstaller/PluginInstallerInterface.md)<br>
