Ling/CheapLogger
================
2019-12-19 --> 2021-05-31




Table of contents
===========

- [CheapLogger](https://github.com/lingtalfi/CheapLogger/blob/master/doc/api/Ling/CheapLogger/CheapLogger.md) &ndash; The CheapLogger class.
    - [CheapLogger::log](https://github.com/lingtalfi/CheapLogger/blob/master/doc/api/Ling/CheapLogger/CheapLogger/log.md) &ndash; Logs the given argument(s) to the log file.
    - [CheapLogger::logg](https://github.com/lingtalfi/CheapLogger/blob/master/doc/api/Ling/CheapLogger/CheapLogger/logg.md) &ndash; Deletes the log file, then recreate it and logs the given argument(s) in it.


Dependencies
============
- [ArrayToString](https://github.com/lingtalfi/ArrayToString)
- [Bat](https://github.com/lingtalfi/Bat)


