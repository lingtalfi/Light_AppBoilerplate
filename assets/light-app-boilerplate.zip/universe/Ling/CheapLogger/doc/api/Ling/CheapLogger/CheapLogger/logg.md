[Back to the Ling/CheapLogger api](https://github.com/lingtalfi/CheapLogger/blob/master/doc/api/Ling/CheapLogger.md)<br>
[Back to the Ling\CheapLogger\CheapLogger class](https://github.com/lingtalfi/CheapLogger/blob/master/doc/api/Ling/CheapLogger/CheapLogger.md)


CheapLogger::logg
================



CheapLogger::logg — Deletes the log file, then recreate it and logs the given argument(s) in it.




Description
================


public static [CheapLogger::logg](https://github.com/lingtalfi/CheapLogger/blob/master/doc/api/Ling/CheapLogger/CheapLogger/logg.md)(...$args) : void




Deletes the log file, then recreate it and logs the given argument(s) in it.




Parameters
================


- args

    


Return values
================

Returns void.








Source Code
===========
See the source code for method [CheapLogger::logg](https://github.com/lingtalfi/CheapLogger/blob/master/CheapLogger.php#L49-L53)


See Also
================

The [CheapLogger](https://github.com/lingtalfi/CheapLogger/blob/master/doc/api/Ling/CheapLogger/CheapLogger.md) class.

Previous method: [log](https://github.com/lingtalfi/CheapLogger/blob/master/doc/api/Ling/CheapLogger/CheapLogger/log.md)<br>Next method: [getLogMessage](https://github.com/lingtalfi/CheapLogger/blob/master/doc/api/Ling/CheapLogger/CheapLogger/getLogMessage.md)<br>

