[Back to the Ling/CheapLogger api](https://github.com/lingtalfi/CheapLogger/blob/master/doc/api/Ling/CheapLogger.md)<br>
[Back to the Ling\CheapLogger\CheapLogger class](https://github.com/lingtalfi/CheapLogger/blob/master/doc/api/Ling/CheapLogger/CheapLogger.md)


CheapLogger::getLogMessage
================



CheapLogger::getLogMessage — Converts the given thing into a log string, and returns it.




Description
================


private static [CheapLogger::getLogMessage](https://github.com/lingtalfi/CheapLogger/blob/master/doc/api/Ling/CheapLogger/CheapLogger/getLogMessage.md)($thing) : string




Converts the given thing into a log string, and returns it.




Parameters
================


- thing

    


Return values
================

Returns string.








Source Code
===========
See the source code for method [CheapLogger::getLogMessage](https://github.com/lingtalfi/CheapLogger/blob/master/CheapLogger.php#L62-L72)


See Also
================

The [CheapLogger](https://github.com/lingtalfi/CheapLogger/blob/master/doc/api/Ling/CheapLogger/CheapLogger.md) class.

Previous method: [logg](https://github.com/lingtalfi/CheapLogger/blob/master/doc/api/Ling/CheapLogger/CheapLogger/logg.md)<br>

