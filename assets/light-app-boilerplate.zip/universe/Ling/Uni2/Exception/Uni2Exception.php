<?php


namespace Ling\Uni2\Exception;


/**
 * The Uni2Exception class.
 * Is thrown whenever a problem occurs in the @object(uni-tool application).
 */
class Uni2Exception extends \Exception
{

}