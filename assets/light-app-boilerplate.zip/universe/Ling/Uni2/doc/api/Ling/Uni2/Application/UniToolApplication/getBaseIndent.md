[Back to the Ling/Uni2 api](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2.md)<br>
[Back to the Ling\Uni2\Application\UniToolApplication class](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2/Application/UniToolApplication.md)


UniToolApplication::getBaseIndent
================



UniToolApplication::getBaseIndent — Returns the baseIndent of this instance.




Description
================


public [UniToolApplication::getBaseIndent](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2/Application/UniToolApplication/getBaseIndent.md)() : int




Returns the baseIndent of this instance.




Parameters
================

This method has no parameters.


Return values
================

Returns int.








Source Code
===========
See the source code for method [UniToolApplication::getBaseIndent](https://github.com/lingtalfi/Uni2/blob/master/Application/UniToolApplication.php#L576-L579)


See Also
================

The [UniToolApplication](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2/Application/UniToolApplication.md) class.

Previous method: [getLocalDependencyMasterPath](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2/Application/UniToolApplication/getLocalDependencyMasterPath.md)<br>Next method: [updateUniToolInfo](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2/Application/UniToolApplication/updateUniToolInfo.md)<br>

