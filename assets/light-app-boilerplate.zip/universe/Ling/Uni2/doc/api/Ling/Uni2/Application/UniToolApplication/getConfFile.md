[Back to the Ling/Uni2 api](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2.md)<br>
[Back to the Ling\Uni2\Application\UniToolApplication class](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2/Application/UniToolApplication.md)


UniToolApplication::getConfFile
================



UniToolApplication::getConfFile — Returns the confFile of this instance.




Description
================


public [UniToolApplication::getConfFile](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2/Application/UniToolApplication/getConfFile.md)() : string




Returns the confFile of this instance.




Parameters
================

This method has no parameters.


Return values
================

Returns string.








Source Code
===========
See the source code for method [UniToolApplication::getConfFile](https://github.com/lingtalfi/Uni2/blob/master/Application/UniToolApplication.php#L382-L385)


See Also
================

The [UniToolApplication](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2/Application/UniToolApplication.md) class.

Previous method: [bootUniverse](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2/Application/UniToolApplication/bootUniverse.md)<br>Next method: [getConf](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2/Application/UniToolApplication/getConf.md)<br>

