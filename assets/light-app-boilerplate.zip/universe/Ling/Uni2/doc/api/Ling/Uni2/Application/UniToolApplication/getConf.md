[Back to the Ling/Uni2 api](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2.md)<br>
[Back to the Ling\Uni2\Application\UniToolApplication class](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2/Application/UniToolApplication.md)


UniToolApplication::getConf
================



UniToolApplication::getConf — Returns the [Uni2 configuration](https://github.com/lingtalfi/Uni2/blob/master/README.md#the-uni2-configuration).




Description
================


public [UniToolApplication::getConf](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2/Application/UniToolApplication/getConf.md)() : array




Returns the [Uni2 configuration](https://github.com/lingtalfi/Uni2/blob/master/README.md#the-uni2-configuration).




Parameters
================

This method has no parameters.


Return values
================

Returns array.








Source Code
===========
See the source code for method [UniToolApplication::getConf](https://github.com/lingtalfi/Uni2/blob/master/Application/UniToolApplication.php#L393-L396)


See Also
================

The [UniToolApplication](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2/Application/UniToolApplication.md) class.

Previous method: [getConfFile](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2/Application/UniToolApplication/getConfFile.md)<br>Next method: [getConfValue](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2/Application/UniToolApplication/getConfValue.md)<br>

