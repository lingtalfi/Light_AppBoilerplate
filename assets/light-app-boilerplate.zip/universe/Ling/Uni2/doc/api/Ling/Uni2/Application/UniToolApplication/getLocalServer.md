[Back to the Ling/Uni2 api](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2.md)<br>
[Back to the Ling\Uni2\Application\UniToolApplication class](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2/Application/UniToolApplication.md)


UniToolApplication::getLocalServer
================



UniToolApplication::getLocalServer — Returns an instance of the local server.




Description
================


public [UniToolApplication::getLocalServer](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2/Application/UniToolApplication/getLocalServer.md)() : [LocalServer](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2/LocalServer/LocalServer.md)




Returns an instance of the local server.




Parameters
================

This method has no parameters.


Return values
================

Returns [LocalServer](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2/LocalServer/LocalServer.md).








Source Code
===========
See the source code for method [UniToolApplication::getLocalServer](https://github.com/lingtalfi/Uni2/blob/master/Application/UniToolApplication.php#L422-L431)


See Also
================

The [UniToolApplication](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2/Application/UniToolApplication.md) class.

Previous method: [getConfValue](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2/Application/UniToolApplication/getConfValue.md)<br>Next method: [copyDependencyMasterFileFromWeb](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2/Application/UniToolApplication/copyDependencyMasterFileFromWeb.md)<br>

