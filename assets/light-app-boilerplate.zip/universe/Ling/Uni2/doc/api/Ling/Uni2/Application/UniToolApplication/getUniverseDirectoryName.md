[Back to the Ling/Uni2 api](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2.md)<br>
[Back to the Ling\Uni2\Application\UniToolApplication class](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2/Application/UniToolApplication.md)


UniToolApplication::getUniverseDirectoryName
================



UniToolApplication::getUniverseDirectoryName — Returns the name of the universe directory.




Description
================


public [UniToolApplication::getUniverseDirectoryName](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2/Application/UniToolApplication/getUniverseDirectoryName.md)() : string




Returns the name of the universe directory.




Parameters
================

This method has no parameters.


Return values
================

Returns string.








Source Code
===========
See the source code for method [UniToolApplication::getUniverseDirectoryName](https://github.com/lingtalfi/Uni2/blob/master/Application/UniToolApplication.php#L281-L284)


See Also
================

The [UniToolApplication](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2/Application/UniToolApplication.md) class.

Previous method: [getUniverseDirectory](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2/Application/UniToolApplication/getUniverseDirectory.md)<br>Next method: [checkApplicationDir](https://github.com/lingtalfi/Uni2/blob/master/doc/api/Ling/Uni2/Application/UniToolApplication/checkApplicationDir.md)<br>

