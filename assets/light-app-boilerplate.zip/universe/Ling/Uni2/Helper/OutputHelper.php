<?php


namespace Ling\Uni2\Helper;


use Ling\CliTools\Helper\VirginiaMessageHelper;

/**
 * The OutputHelper class.
 * Contains helpers related to the @object(output object).
 */
class OutputHelper extends VirginiaMessageHelper
{



}