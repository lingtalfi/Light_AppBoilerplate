[Back to the Ling/ParenthesisMirrorParser api](https://github.com/lingtalfi/ParenthesisMirrorParser/blob/master/doc/api/Ling/ParenthesisMirrorParser.md)<br>
[Back to the Ling\ParenthesisMirrorParser\ParenthesisMirrorParser class](https://github.com/lingtalfi/ParenthesisMirrorParser/blob/master/doc/api/Ling/ParenthesisMirrorParser/ParenthesisMirrorParser.md)


ParenthesisMirrorParser::__construct
================



ParenthesisMirrorParser::__construct — Builds the ParenthesisMirrorParser instance.




Description
================


public [ParenthesisMirrorParser::__construct](https://github.com/lingtalfi/ParenthesisMirrorParser/blob/master/doc/api/Ling/ParenthesisMirrorParser/ParenthesisMirrorParser/__construct.md)() : void




Builds the ParenthesisMirrorParser instance.




Parameters
================

This method has no parameters.


Return values
================

Returns void.








Source Code
===========
See the source code for method [ParenthesisMirrorParser::__construct](https://github.com/lingtalfi/ParenthesisMirrorParser/blob/master/ParenthesisMirrorParser.php#L30-L36)


See Also
================

The [ParenthesisMirrorParser](https://github.com/lingtalfi/ParenthesisMirrorParser/blob/master/doc/api/Ling/ParenthesisMirrorParser/ParenthesisMirrorParser.md) class.

Next method: [setIdentifier](https://github.com/lingtalfi/ParenthesisMirrorParser/blob/master/doc/api/Ling/ParenthesisMirrorParser/ParenthesisMirrorParser/setIdentifier.md)<br>

