[Back to the Ling/ParenthesisMirrorParser api](https://github.com/lingtalfi/ParenthesisMirrorParser/blob/master/doc/api/Ling/ParenthesisMirrorParser.md)<br>
[Back to the Ling\ParenthesisMirrorParser\ParenthesisMirrorParser class](https://github.com/lingtalfi/ParenthesisMirrorParser/blob/master/doc/api/Ling/ParenthesisMirrorParser/ParenthesisMirrorParser.md)


ParenthesisMirrorParser::setIdentifier
================



ParenthesisMirrorParser::setIdentifier — Sets the identifier.




Description
================


public [ParenthesisMirrorParser::setIdentifier](https://github.com/lingtalfi/ParenthesisMirrorParser/blob/master/doc/api/Ling/ParenthesisMirrorParser/ParenthesisMirrorParser/setIdentifier.md)(string $identifier) : void




Sets the identifier.




Parameters
================


- identifier

    


Return values
================

Returns void.








Source Code
===========
See the source code for method [ParenthesisMirrorParser::setIdentifier](https://github.com/lingtalfi/ParenthesisMirrorParser/blob/master/ParenthesisMirrorParser.php#L43-L46)


See Also
================

The [ParenthesisMirrorParser](https://github.com/lingtalfi/ParenthesisMirrorParser/blob/master/doc/api/Ling/ParenthesisMirrorParser/ParenthesisMirrorParser.md) class.

Previous method: [__construct](https://github.com/lingtalfi/ParenthesisMirrorParser/blob/master/doc/api/Ling/ParenthesisMirrorParser/ParenthesisMirrorParser/__construct.md)<br>Next method: [setConverter](https://github.com/lingtalfi/ParenthesisMirrorParser/blob/master/doc/api/Ling/ParenthesisMirrorParser/ParenthesisMirrorParser/setConverter.md)<br>

