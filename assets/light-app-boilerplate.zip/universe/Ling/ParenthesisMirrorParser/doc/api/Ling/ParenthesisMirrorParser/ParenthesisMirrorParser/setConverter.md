[Back to the Ling/ParenthesisMirrorParser api](https://github.com/lingtalfi/ParenthesisMirrorParser/blob/master/doc/api/Ling/ParenthesisMirrorParser.md)<br>
[Back to the Ling\ParenthesisMirrorParser\ParenthesisMirrorParser class](https://github.com/lingtalfi/ParenthesisMirrorParser/blob/master/doc/api/Ling/ParenthesisMirrorParser/ParenthesisMirrorParser.md)


ParenthesisMirrorParser::setConverter
================



ParenthesisMirrorParser::setConverter — Sets the converter.




Description
================


public [ParenthesisMirrorParser::setConverter](https://github.com/lingtalfi/ParenthesisMirrorParser/blob/master/doc/api/Ling/ParenthesisMirrorParser/ParenthesisMirrorParser/setConverter.md)(callable $converter) : void




Sets the converter.




Parameters
================


- converter

    


Return values
================

Returns void.








Source Code
===========
See the source code for method [ParenthesisMirrorParser::setConverter](https://github.com/lingtalfi/ParenthesisMirrorParser/blob/master/ParenthesisMirrorParser.php#L53-L56)


See Also
================

The [ParenthesisMirrorParser](https://github.com/lingtalfi/ParenthesisMirrorParser/blob/master/doc/api/Ling/ParenthesisMirrorParser/ParenthesisMirrorParser.md) class.

Previous method: [setIdentifier](https://github.com/lingtalfi/ParenthesisMirrorParser/blob/master/doc/api/Ling/ParenthesisMirrorParser/ParenthesisMirrorParser/setIdentifier.md)<br>Next method: [parseString](https://github.com/lingtalfi/ParenthesisMirrorParser/blob/master/doc/api/Ling/ParenthesisMirrorParser/ParenthesisMirrorParser/parseString.md)<br>

