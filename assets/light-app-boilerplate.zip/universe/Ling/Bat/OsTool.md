OsTool
=====================
2019-04-01



This class contains functions related to the current os.



hasProgram
------------

This method returns whether or not the underlying OS has the program
which real/full path is specified.


isWindows
------------

This method returns whether or not the underlying OS is Windows.

isMac
------------

This method returns whether or not the underlying OS is MacOsX.



isUnix
------------

This method returns whether or not the underlying OS is a Unix. 


clear
----------
Clears the console screen.
