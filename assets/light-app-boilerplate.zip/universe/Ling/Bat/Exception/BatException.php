<?php


namespace Ling\Bat\Exception;


/**
 * The BatException class.
 *
 */
class BatException extends \Exception
{

}


