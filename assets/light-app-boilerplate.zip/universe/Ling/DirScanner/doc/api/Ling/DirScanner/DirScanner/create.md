[Back to the Ling/DirScanner api](https://github.com/lingtalfi/DirScanner/blob/master/doc/api/Ling/DirScanner.md)<br>
[Back to the Ling\DirScanner\DirScanner class](https://github.com/lingtalfi/DirScanner/blob/master/doc/api/Ling/DirScanner/DirScanner.md)


DirScanner::create
================



DirScanner::create — A static way of instantiating the class.




Description
================


public static [DirScanner::create](https://github.com/lingtalfi/DirScanner/blob/master/doc/api/Ling/DirScanner/DirScanner/create.md)() : [DirScanner](https://github.com/lingtalfi/DirScanner/blob/master/doc/api/Ling/DirScanner/DirScanner.md)




A static way of instantiating the class.




Parameters
================

This method has no parameters.


Return values
================

Returns [DirScanner](https://github.com/lingtalfi/DirScanner/blob/master/doc/api/Ling/DirScanner/DirScanner.md).








Source Code
===========
See the source code for method [DirScanner::create](https://github.com/lingtalfi/DirScanner/blob/master/DirScanner.php#L46-L49)


See Also
================

The [DirScanner](https://github.com/lingtalfi/DirScanner/blob/master/doc/api/Ling/DirScanner/DirScanner.md) class.

Previous method: [__construct](https://github.com/lingtalfi/DirScanner/blob/master/doc/api/Ling/DirScanner/DirScanner/__construct.md)<br>Next method: [scanDir](https://github.com/lingtalfi/DirScanner/blob/master/doc/api/Ling/DirScanner/DirScanner/scanDir.md)<br>

