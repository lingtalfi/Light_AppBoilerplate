[Back to the Ling/DirScanner api](https://github.com/lingtalfi/DirScanner/blob/master/doc/api/Ling/DirScanner.md)<br>
[Back to the Ling\DirScanner\NestedFileTreeHelper class](https://github.com/lingtalfi/DirScanner/blob/master/doc/api/Ling/DirScanner/NestedFileTreeHelper.md)


NestedFileTreeHelper::doIterate
================



NestedFileTreeHelper::doIterate — The working horse behind the getNestedFileTree method.




Description
================


private static [NestedFileTreeHelper::doIterate](https://github.com/lingtalfi/DirScanner/blob/master/doc/api/Ling/DirScanner/NestedFileTreeHelper/doIterate.md)(string $dir, ?array $options = []) : array




The working horse behind the getNestedFileTree method.




Parameters
================


- dir

    

- options

    


Return values
================

Returns array.








Source Code
===========
See the source code for method [NestedFileTreeHelper::doIterate](https://github.com/lingtalfi/DirScanner/blob/master/NestedFileTreeHelper.php#L65-L137)


See Also
================

The [NestedFileTreeHelper](https://github.com/lingtalfi/DirScanner/blob/master/doc/api/Ling/DirScanner/NestedFileTreeHelper.md) class.

Previous method: [getNestedFileTree](https://github.com/lingtalfi/DirScanner/blob/master/doc/api/Ling/DirScanner/NestedFileTreeHelper/getNestedFileTree.md)<br>

