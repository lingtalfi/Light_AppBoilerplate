[Back to the Ling/DirScanner api](https://github.com/lingtalfi/DirScanner/blob/master/doc/api/Ling/DirScanner.md)<br>
[Back to the Ling\DirScanner\DirScanner class](https://github.com/lingtalfi/DirScanner/blob/master/doc/api/Ling/DirScanner/DirScanner.md)


DirScanner::__construct
================



DirScanner::__construct — Builds the DirScanner instance.




Description
================


public [DirScanner::__construct](https://github.com/lingtalfi/DirScanner/blob/master/doc/api/Ling/DirScanner/DirScanner/__construct.md)() : void




Builds the DirScanner instance.




Parameters
================

This method has no parameters.


Return values
================

Returns void.








Source Code
===========
See the source code for method [DirScanner::__construct](https://github.com/lingtalfi/DirScanner/blob/master/DirScanner.php#L35-L38)


See Also
================

The [DirScanner](https://github.com/lingtalfi/DirScanner/blob/master/doc/api/Ling/DirScanner/DirScanner.md) class.

Next method: [create](https://github.com/lingtalfi/DirScanner/blob/master/doc/api/Ling/DirScanner/DirScanner/create.md)<br>

