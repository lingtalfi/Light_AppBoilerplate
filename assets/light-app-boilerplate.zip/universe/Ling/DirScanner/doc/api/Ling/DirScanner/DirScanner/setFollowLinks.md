[Back to the Ling/DirScanner api](https://github.com/lingtalfi/DirScanner/blob/master/doc/api/Ling/DirScanner.md)<br>
[Back to the Ling\DirScanner\DirScanner class](https://github.com/lingtalfi/DirScanner/blob/master/doc/api/Ling/DirScanner/DirScanner.md)


DirScanner::setFollowLinks
================



DirScanner::setFollowLinks — Sets the followLinks property for this instance.




Description
================


public [DirScanner::setFollowLinks](https://github.com/lingtalfi/DirScanner/blob/master/doc/api/Ling/DirScanner/DirScanner/setFollowLinks.md)(bool $followLinks) : [DirScanner](https://github.com/lingtalfi/DirScanner/blob/master/doc/api/Ling/DirScanner/DirScanner.md)




Sets the followLinks property for this instance.




Parameters
================


- followLinks

    


Return values
================

Returns [DirScanner](https://github.com/lingtalfi/DirScanner/blob/master/doc/api/Ling/DirScanner/DirScanner.md).








Source Code
===========
See the source code for method [DirScanner::setFollowLinks](https://github.com/lingtalfi/DirScanner/blob/master/DirScanner.php#L97-L101)


See Also
================

The [DirScanner](https://github.com/lingtalfi/DirScanner/blob/master/doc/api/Ling/DirScanner/DirScanner.md) class.

Previous method: [scanDir](https://github.com/lingtalfi/DirScanner/blob/master/doc/api/Ling/DirScanner/DirScanner/scanDir.md)<br>Next method: [doScanDir](https://github.com/lingtalfi/DirScanner/blob/master/doc/api/Ling/DirScanner/DirScanner/doScanDir.md)<br>

