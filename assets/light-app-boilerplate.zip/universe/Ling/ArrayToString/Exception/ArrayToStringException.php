<?php

namespace Ling\ArrayToString\Exception;

/*
 * LingTalfi 2015-10-26
 */
class ArrayToStringException extends \Exception {

}
